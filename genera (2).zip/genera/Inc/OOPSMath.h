/*
  ==============================================================================

    OOPSMath.h
    Created: 22 Jan 2017 7:02:56pm
    Author:  Michael R Mulshine

  ==============================================================================
*/

#ifndef OOPSMATH_H_INCLUDED
#define OOPSMATH_H_INCLUDED

#include "math.h"
#include "stdint.h"
#include "stdlib.h"


typedef enum oBool
{
    OTRUE  = 1,
    OFALSE = 0
}oBool;



#define SQRT8 2.82842712475
#define WSCALE 1.30612244898
#define PI              (3.14159265358979f)
#define TWO_PI          (2 * PI)

#define VSF             1.0e-38f

#define MAX_DELAY       8192
#define INV_128         (1.0f / 128.0f)

#define INV_20         0.05f
#define INV_40         0.025
#define INV_80         0.0125f
#define INV_160        0.00625f
#define INV_320        0.003125f
#define INV_640        0.0015625f
#define INV_1280       0.00078125f
#define INV_2560       0.000390625f
#define INV_5120       0.0001953125f
#define INV_10240      0.00009765625f
#define INV_20480      0.000048828125f

#define FUNDAMENTAL_HZ 58.27f
#define FUNDAMENTAL_CM 294.31955f;
#define FUNDAMENTAL_M 2.9431955f
#define INV_FUNDAMENTAL_M 0.3397676f

#define INV_TWELVE 0.0833333333
#define INV_440 0.0022727273f

#define LOG2 0.3010299957f
#define INV_LOG2 3.321928095f

#define SOS_M 343.0f

#define TWO_TO_8 256.f
#define INV_TWO_TO_8 1.f/TWO_TO_8
#define TWO_TO_5 32.f
#define INV_TWO_TO_5 1.0f/TWO_TO_5
#define TWO_TO_12 4096.f
#define INV_TWO_TO_12 1.f/TWO_TO_12
#define TWO_TO_15 32768.f
#define TWO_TO_16 65536.f
#define INV_TWO_TO_15 1.0f/TWO_TO_15
#define TWO_TO_16_MINUS_ONE 65535.0f

// Erbe shaper
float OOPS_shaper(float input, float m_drive);
float OOPS_reedTable(float input, float offset, float slope);

float       OOPS_clip               (float min, float val, float max);
oBool       OOPS_isPrime            (uint64_t number );
float       OOPS_midiToFrequency    (float f);

// dope af
float OOPS_chebyshevT(float in, int n);
float OOPS_frequencyToMidi(float f);



#endif  // OOPSMATH_H_INCLUDED
