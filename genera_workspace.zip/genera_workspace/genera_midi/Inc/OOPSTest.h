/*
  ==============================================================================

    MyTest.h
    Created: 23 Jan 2017 9:39:38am
    Author:  Michael R Mulshine

  ==============================================================================
*/

#include "OOPS.h"

extern tMPoly* poly;

extern tCycle* osc[NUM_VOICES];

extern tTalkbox* tb;

extern tCycle* sine;

